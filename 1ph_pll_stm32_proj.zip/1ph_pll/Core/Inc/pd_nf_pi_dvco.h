/*
 * File: pd_nf_pi_dvco.h
 *
 * Code generated for Simulink model 'pd_nf_pi_dvco'.
 *
 * Model version                  : 1.32
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Sun Jun 23 10:34:04 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: AMD->Athlon 64
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pd_nf_pi_dvco_h_
#define RTW_HEADER_pd_nf_pi_dvco_h_
#ifndef pd_nf_pi_dvco_COMMON_INCLUDES_
#define pd_nf_pi_dvco_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* pd_nf_pi_dvco_COMMON_INCLUDES_ */

#include "rt_nonfinite.h"
#ifndef struct_tag_BlgwLpgj2bjudmbmVKWwDE
#define struct_tag_BlgwLpgj2bjudmbmVKWwDE

struct tag_BlgwLpgj2bjudmbmVKWwDE
{
  uint32_T f1[8];
};

#endif                                 /* struct_tag_BlgwLpgj2bjudmbmVKWwDE */

#ifndef typedef_cell_wrap_pd_nf_pi_dvco_T
#define typedef_cell_wrap_pd_nf_pi_dvco_T

typedef struct tag_BlgwLpgj2bjudmbmVKWwDE cell_wrap_pd_nf_pi_dvco_T;

#endif                                 /* typedef_cell_wrap_pd_nf_pi_dvco_T */

#ifndef struct_tag_uuKjcHa6pivwHF8q6dEmyE
#define struct_tag_uuKjcHa6pivwHF8q6dEmyE

struct tag_uuKjcHa6pivwHF8q6dEmyE
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  boolean_T TunablePropsChanged;
  cell_wrap_pd_nf_pi_dvco_T inputVarSize[2];
  real_T Bandwidth;
  real_T CenterFrequency;
  real_T privBandwidthCoefficient;
  real_T privCenterFrequencyCoefficient;
  int32_T NumChannels;
  real_T States[2];
};

#endif                                 /* struct_tag_uuKjcHa6pivwHF8q6dEmyE */

#ifndef typedef_dsp_simulink_NotchPeakFilter__T
#define typedef_dsp_simulink_NotchPeakFilter__T

typedef struct tag_uuKjcHa6pivwHF8q6dEmyE dsp_simulink_NotchPeakFilter__T;

#endif                             /* typedef_dsp_simulink_NotchPeakFilter__T */

/* Block signals and states (default storage) for model 'pd_nf_pi_dvco' */
typedef struct {
  dsp_simulink_NotchPeakFilter__T obj; /* '<Root>/Notch-Peak Filter' */
  real_T Delay_DSTATE[2];              /* '<Root>/Delay' */
  real_T Delay_DSTATE_j;               /* '<S2>/Delay' */
  real_T Integrator_DSTATE;            /* '<S34>/Integrator' */
  real_T Memory_PreviousInput;         /* '<S2>/Memory' */
  real_T Memory2_PreviousInput;        /* '<S2>/Memory2' */
  real_T Memory1_PreviousInput;        /* '<S2>/Memory1' */
  boolean_T objisempty;                /* '<Root>/Notch-Peak Filter' */
} DW_pd_nf_pi_dvco_f_T;

typedef struct {
  DW_pd_nf_pi_dvco_f_T rtdw;
} MdlrefDW_pd_nf_pi_dvco_T;

/* Model reference registration function */
extern void pd_nf_pi_dvco_initialize(void);
extern void pd_nf_pi_dvco_Init(DW_pd_nf_pi_dvco_f_T *localDW);
extern void pd_nf_pi_dvco(const real_T *rtu_Input, real_T *rty_th, real_T
  *rty_sin_th, real_T *rty_freq, DW_pd_nf_pi_dvco_f_T *localDW);

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Sin' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pd_nf_pi_dvco'
 * '<S1>'   : 'pd_nf_pi_dvco/PID Controller'
 * '<S2>'   : 'pd_nf_pi_dvco/dco'
 * '<S3>'   : 'pd_nf_pi_dvco/PID Controller/Anti-windup'
 * '<S4>'   : 'pd_nf_pi_dvco/PID Controller/D Gain'
 * '<S5>'   : 'pd_nf_pi_dvco/PID Controller/Filter'
 * '<S6>'   : 'pd_nf_pi_dvco/PID Controller/Filter ICs'
 * '<S7>'   : 'pd_nf_pi_dvco/PID Controller/I Gain'
 * '<S8>'   : 'pd_nf_pi_dvco/PID Controller/Ideal P Gain'
 * '<S9>'   : 'pd_nf_pi_dvco/PID Controller/Ideal P Gain Fdbk'
 * '<S10>'  : 'pd_nf_pi_dvco/PID Controller/Integrator'
 * '<S11>'  : 'pd_nf_pi_dvco/PID Controller/Integrator ICs'
 * '<S12>'  : 'pd_nf_pi_dvco/PID Controller/N Copy'
 * '<S13>'  : 'pd_nf_pi_dvco/PID Controller/N Gain'
 * '<S14>'  : 'pd_nf_pi_dvco/PID Controller/P Copy'
 * '<S15>'  : 'pd_nf_pi_dvco/PID Controller/Parallel P Gain'
 * '<S16>'  : 'pd_nf_pi_dvco/PID Controller/Reset Signal'
 * '<S17>'  : 'pd_nf_pi_dvco/PID Controller/Saturation'
 * '<S18>'  : 'pd_nf_pi_dvco/PID Controller/Saturation Fdbk'
 * '<S19>'  : 'pd_nf_pi_dvco/PID Controller/Sum'
 * '<S20>'  : 'pd_nf_pi_dvco/PID Controller/Sum Fdbk'
 * '<S21>'  : 'pd_nf_pi_dvco/PID Controller/Tracking Mode'
 * '<S22>'  : 'pd_nf_pi_dvco/PID Controller/Tracking Mode Sum'
 * '<S23>'  : 'pd_nf_pi_dvco/PID Controller/Tsamp - Integral'
 * '<S24>'  : 'pd_nf_pi_dvco/PID Controller/Tsamp - Ngain'
 * '<S25>'  : 'pd_nf_pi_dvco/PID Controller/postSat Signal'
 * '<S26>'  : 'pd_nf_pi_dvco/PID Controller/preSat Signal'
 * '<S27>'  : 'pd_nf_pi_dvco/PID Controller/Anti-windup/Passthrough'
 * '<S28>'  : 'pd_nf_pi_dvco/PID Controller/D Gain/Disabled'
 * '<S29>'  : 'pd_nf_pi_dvco/PID Controller/Filter/Disabled'
 * '<S30>'  : 'pd_nf_pi_dvco/PID Controller/Filter ICs/Disabled'
 * '<S31>'  : 'pd_nf_pi_dvco/PID Controller/I Gain/Internal Parameters'
 * '<S32>'  : 'pd_nf_pi_dvco/PID Controller/Ideal P Gain/Passthrough'
 * '<S33>'  : 'pd_nf_pi_dvco/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S34>'  : 'pd_nf_pi_dvco/PID Controller/Integrator/Discrete'
 * '<S35>'  : 'pd_nf_pi_dvco/PID Controller/Integrator ICs/Internal IC'
 * '<S36>'  : 'pd_nf_pi_dvco/PID Controller/N Copy/Disabled wSignal Specification'
 * '<S37>'  : 'pd_nf_pi_dvco/PID Controller/N Gain/Disabled'
 * '<S38>'  : 'pd_nf_pi_dvco/PID Controller/P Copy/Disabled'
 * '<S39>'  : 'pd_nf_pi_dvco/PID Controller/Parallel P Gain/Internal Parameters'
 * '<S40>'  : 'pd_nf_pi_dvco/PID Controller/Reset Signal/Disabled'
 * '<S41>'  : 'pd_nf_pi_dvco/PID Controller/Saturation/Passthrough'
 * '<S42>'  : 'pd_nf_pi_dvco/PID Controller/Saturation Fdbk/Disabled'
 * '<S43>'  : 'pd_nf_pi_dvco/PID Controller/Sum/Sum_PI'
 * '<S44>'  : 'pd_nf_pi_dvco/PID Controller/Sum Fdbk/Disabled'
 * '<S45>'  : 'pd_nf_pi_dvco/PID Controller/Tracking Mode/Disabled'
 * '<S46>'  : 'pd_nf_pi_dvco/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S47>'  : 'pd_nf_pi_dvco/PID Controller/Tsamp - Integral/Passthrough'
 * '<S48>'  : 'pd_nf_pi_dvco/PID Controller/Tsamp - Ngain/Passthrough'
 * '<S49>'  : 'pd_nf_pi_dvco/PID Controller/postSat Signal/Forward_Path'
 * '<S50>'  : 'pd_nf_pi_dvco/PID Controller/preSat Signal/Forward_Path'
 * '<S51>'  : 'pd_nf_pi_dvco/dco/MATLAB Function'
 */
#endif                                 /* RTW_HEADER_pd_nf_pi_dvco_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
