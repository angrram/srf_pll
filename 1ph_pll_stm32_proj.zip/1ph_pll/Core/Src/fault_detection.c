/*
 * File: fault_detection.c
 *
 * Code generated for Simulink model 'fault_detection'.
 *
 * Model version                  : 1.13
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Sun Jun 23 10:33:45 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: AMD->Athlon 64
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "fault_detection.h"
#include "rtwtypes.h"

/* Output and update for referenced model: 'fault_detection' */
void fault_detection(const real_T *rtu_v_line, const real_T *rtu_sine, const
                     real_T *rtu_freq, real_T rty_id_fault[2])
{
  real_T rtb_Sum;
  boolean_T rtb_Equal2;
  boolean_T rtb_Equal3;

  /* Sum: '<Root>/Sum' */
  rtb_Sum = *rtu_v_line - *rtu_sine;

  /* RelationalOperator: '<Root>/Equal3' incorporates:
   *  Constant: '<Root>/Constant3'
   */
  rtb_Equal3 = (*rtu_freq > 415.0);

  /* RelationalOperator: '<Root>/Equal2' incorporates:
   *  Constant: '<Root>/Constant2'
   */
  rtb_Equal2 = (*rtu_freq < 276.0);

  /* DataTypeConversion: '<Root>/Data Type Conversion' incorporates:
   *  Constant: '<Root>/Constant'
   *  Constant: '<Root>/Constant1'
   *  Logic: '<Root>/AND'
   *  Logic: '<Root>/AND1'
   *  RelationalOperator: '<Root>/Equal'
   *  RelationalOperator: '<Root>/Equal1'
   */
  rty_id_fault[0] = ((rtb_Sum > 0.2) || (rtb_Sum < -0.2));
  rty_id_fault[1] = (rtb_Equal3 || rtb_Equal2);
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
