/*
 * File: pd_nf_pi_dvco.c
 *
 * Code generated for Simulink model 'pd_nf_pi_dvco'.
 *
 * Model version                  : 1.32
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Sun Jun 23 10:34:04 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: AMD->Athlon 64
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "pd_nf_pi_dvco.h"
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Forward declaration for local functions */
static void pd_nf_pi_dvco_SystemCore_setup(dsp_simulink_NotchPeakFilter__T *obj);
static void pd_nf_pi_dvco_SystemCore_setup(dsp_simulink_NotchPeakFilter__T *obj)
{
  obj->isInitialized = 1;
  obj->CenterFrequency = 0.0;
  obj->States[0] = 0.0;
  obj->States[1] = 0.0;
  obj->NumChannels = 1;
  obj->privBandwidthCoefficient = 2.0 / (tan(obj->Bandwidth * 3.1415926535897931
    / 5000.0) + 1.0) - 1.0;
  obj->privCenterFrequencyCoefficient = -cos(2.0 * obj->CenterFrequency / 5000.0
    * 3.1415926535897931);
  obj->isSetupComplete = true;
  obj->TunablePropsChanged = false;
}

/* System initialize for referenced model: 'pd_nf_pi_dvco' */
void pd_nf_pi_dvco_Init(DW_pd_nf_pi_dvco_f_T *localDW)
{
  /* InitializeConditions for Delay: '<Root>/Delay' */
  localDW->Delay_DSTATE[0] = 110.0;
  localDW->Delay_DSTATE[1] = 110.0;

  /* InitializeConditions for Memory: '<S2>/Memory' */
  localDW->Memory_PreviousInput = 0.99;

  /* Start for MATLABSystem: '<Root>/Notch-Peak Filter' */
  localDW->obj.isInitialized = 0;
  localDW->obj.NumChannels = -1;
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  if (localDW->obj.isInitialized == 1) {
    localDW->obj.TunablePropsChanged = true;
  }

  localDW->obj.Bandwidth = 800.0;
  pd_nf_pi_dvco_SystemCore_setup(&localDW->obj);

  /* End of Start for MATLABSystem: '<Root>/Notch-Peak Filter' */

  /* InitializeConditions for MATLABSystem: '<Root>/Notch-Peak Filter' */
  localDW->obj.States[0] = 0.0;
  localDW->obj.States[1] = 0.0;
}

/* Output and update for referenced model: 'pd_nf_pi_dvco' */
void pd_nf_pi_dvco(const real_T *rtu_Input, real_T *rty_th, real_T *rty_sin_th,
                   real_T *rty_freq, DW_pd_nf_pi_dvco_f_T *localDW)
{
  real_T p3dB;
  real_T pcf;
  real_T rtb_PD;
  real_T s3dB;
  real_T z1;

  /* Product: '<Root>/Product' incorporates:
   *  Delay: '<S2>/Delay'
   */
  rtb_PD = localDW->Delay_DSTATE_j * *rtu_Input;

  /* MATLABSystem: '<Root>/Notch-Peak Filter' incorporates:
   *  Delay: '<Root>/Delay'
   */
  if (localDW->obj.Bandwidth != 800.0) {
    if (localDW->obj.isInitialized == 1) {
      localDW->obj.TunablePropsChanged = true;
    }

    localDW->obj.Bandwidth = 800.0;
  }

  if ((localDW->obj.CenterFrequency == localDW->Delay_DSTATE[0U]) || (rtIsNaN
       (localDW->obj.CenterFrequency) && rtIsNaN(localDW->Delay_DSTATE[0U]))) {
  } else {
    if (localDW->obj.isInitialized == 1) {
      localDW->obj.TunablePropsChanged = true;
    }

    localDW->obj.CenterFrequency = localDW->Delay_DSTATE[0];
  }

  if (localDW->obj.TunablePropsChanged) {
    localDW->obj.TunablePropsChanged = false;
    localDW->obj.privBandwidthCoefficient = 2.0 / (tan(localDW->obj.Bandwidth *
      3.1415926535897931 / 5000.0) + 1.0) - 1.0;
    localDW->obj.privCenterFrequencyCoefficient = -cos(2.0 *
      localDW->obj.CenterFrequency / 5000.0 * 3.1415926535897931);
  }

  z1 = localDW->obj.States[0];
  rtb_PD *= 0.5;
  p3dB = (rtb_PD - localDW->obj.States[0]) *
    localDW->obj.privBandwidthCoefficient;
  s3dB = rtb_PD + p3dB;
  pcf = (s3dB - localDW->obj.States[1]) *
    localDW->obj.privCenterFrequencyCoefficient;
  localDW->obj.States[0] = pcf + localDW->obj.States[1];
  localDW->obj.States[1] = s3dB + pcf;
  z1 = (p3dB + z1) + rtb_PD;

  /* End of MATLABSystem: '<Root>/Notch-Peak Filter' */

  /* Sum: '<S43>/Sum' incorporates:
   *  DiscreteIntegrator: '<S34>/Integrator'
   *  Gain: '<S39>/Proportional Gain'
   */
  rtb_PD = 600.0 * z1 + localDW->Integrator_DSTATE;

  /* MATLAB Function: '<S2>/MATLAB Function' incorporates:
   *  Constant: '<S2>/Constant'
   *  Memory: '<S2>/Memory'
   *  Memory: '<S2>/Memory1'
   *  Memory: '<S2>/Memory2'
   */
  p3dB = (rtb_PD + 345.57519189487726) * localDW->Memory_PreviousInput * 0.0002
    + localDW->Memory2_PreviousInput;
  if (p3dB < -1.0) {
    s3dB = -1.0;
  } else if (rtIsNaN(p3dB)) {
    s3dB = -1.0;
  } else {
    s3dB = p3dB;
  }

  p3dB = localDW->Memory_PreviousInput - (rtb_PD + 345.57519189487726) *
    localDW->Memory2_PreviousInput * 0.0002;
  if (p3dB < -1.0) {
    p3dB = -1.0;
  } else if (rtIsNaN(p3dB)) {
    p3dB = -1.0;
  }

  if (s3dB > 1.0) {
    s3dB = 1.0;
  }

  if (p3dB > 1.0) {
    p3dB = 1.0;
  }

  *rty_th = (rtb_PD + 345.57519189487726) * 0.0002 +
    localDW->Memory1_PreviousInput;
  if ((localDW->Memory2_PreviousInput >= 0.0) && (s3dB <= 0.0)) {
    *rty_th = -3.1415926535897931;
  }

  *rty_sin_th = s3dB;

  /* Gain: '<S2>/Gain1' incorporates:
   *  MATLAB Function: '<S2>/MATLAB Function'
   */
  *rty_freq = (rtb_PD + 345.57519189487726) * 0.15915494309189535;

  /* Update for Delay: '<Root>/Delay' incorporates:
   *  Gain: '<Root>/Gain'
   */
  localDW->Delay_DSTATE[0] = localDW->Delay_DSTATE[1];
  localDW->Delay_DSTATE[1] = 2.0 * *rty_freq;

  /* Update for Delay: '<S2>/Delay' */
  localDW->Delay_DSTATE_j = p3dB;

  /* Update for DiscreteIntegrator: '<S34>/Integrator' incorporates:
   *  Gain: '<S31>/Integral Gain'
   */
  localDW->Integrator_DSTATE += 2.0 * z1;

  /* Update for Memory: '<S2>/Memory' */
  localDW->Memory_PreviousInput = p3dB;

  /* Update for Memory: '<S2>/Memory2' */
  localDW->Memory2_PreviousInput = *rty_sin_th;

  /* Update for Memory: '<S2>/Memory1' */
  localDW->Memory1_PreviousInput = *rty_th;
}

/* Model initialize function */
void pd_nf_pi_dvco_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
